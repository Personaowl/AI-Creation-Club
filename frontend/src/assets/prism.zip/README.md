# Prism
一个用于浮光作品库演示的 CSS 组件。
为容器添加 prism-panel 类即可使用。
